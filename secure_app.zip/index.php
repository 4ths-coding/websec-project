<!DOCTYPE html>
<html>
<head>
    <title>Secure Login System</title>
</head>
<body>
    <h2>Login</h2>
    <form method="POST" action="login.php">
        Username: <input type="text" name="username" required><br>
        Password: <input type="password" name="password" required><br>
        <input type="submit" value="Login">
    </form>

    <p>Don't have an account? <a href="register.html">Register here</a></p>
</body>
</html>
